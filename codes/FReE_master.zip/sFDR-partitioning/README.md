# FReE - Fractal Redundancy Elimination
## A novel algorithm to reduce the dimensionality Very Large Datasets in a parallel and distributed way.


### How to use the FReE?
_Firstly, you need to have the Spark setted in your machine/cluster_ 
1. To generate the .jar file, you just need use the maven tool: ```mvn package``` in the root directory.
2. Go to target directory and put the following command:
```shell
spark-submit --class Main ./sFDR-1.0.jar <offset> <inputPath> <outputPath> <dimensionality> <countingTreeLevels> <normalizedDataset> <blockSize> <threshold>
```
* ```<offset>```: use it in case your dataset has a column with class labels, for example: 1 in case of class in the first column;
* ```<inputPath>```: the dataset input path;
* ```<outputPath>```: the path to save the output file;
* ```<dimensionality>```: the number of dimensions in the dataset;
* ```<countingTreeLevels>```: the number of levels to use in the counting tree.
* ```<blockSize>```: the block size is the maximum limit of feature in each block.
* ```<threshold>```: the loss threshold in each dimensionality reduction step.

The technique will shows the relevant attributes (non-redundant attributes) that you need to maintain in your dataset.
