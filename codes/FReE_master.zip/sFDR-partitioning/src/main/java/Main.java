import core.TreeMapper;
import core.TreeReducer;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.storage.StorageLevel;
import utils.Fractal;
import utils.PointsDistribution;
import utils.Reducer;
import utils.Triple;

import java.io.*;
import java.util.*;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */
public class Main {

    private final static Logger LOGGER = Logger.getLogger("mscAlgorithm");
    private final static StringBuilder stringBuilder = new StringBuilder();
    private static BufferedWriter bufferedWriter;


    public static void main(final String[] args) {

        //final SparkConf sparkConf = new SparkConf().setAppName("sFDR").setMaster("local[*]");
        final SparkConf sparkConf = new SparkConf().setAppName("sFDR");
        sparkConf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer");
        final JavaSparkContext javaSparkContext = new JavaSparkContext(sparkConf);

        if (args.length != 8) {
            LOGGER.error("Please enter with the following parameters: [0] labeled, [1] inputPath, [2] outputPath, [3] dimensionality, [4] treeLevel, [5] normalized, [6] blockSize");
            System.exit(1);
        }

        //Parse all parameters
        final int labeled = Integer.parseInt(args[0]);
        final String inputPath = args[1];
        final String outputPath = args[2];
        final int dimensionality = Integer.parseInt(args[3]);
        final int treeLevel = Integer.parseInt(args[4]);
        final boolean datasetNormalized = Boolean.parseBoolean(args[5]);
        final int blockSize = Integer.parseInt(args[6]);
        final double limitCut = Integer.parseInt(args[7]) / 100.0;


        //Initial time
        final double initialTime = System.currentTimeMillis();

        //Initialize the BufferedWriter
        try {
            bufferedWriter = new BufferedWriter(new FileWriter(outputPath));
        } catch (final FileNotFoundException e) {
            e.printStackTrace();
        } catch (final IOException e) {
            e.printStackTrace();
        }

        LOGGER.debug("Reading dataset file...");
        final JavaRDD<String> datasetFile = javaSparkContext.textFile(inputPath);

        double[] minValues = new double[dimensionality + labeled];
        double[] maxValues = new double[dimensionality + labeled];

        if (!datasetNormalized) {
            LOGGER.info("Normalizing dataset...");

            final JavaRDD<double[]> datasetPoints = datasetFile.mapPartitions(new FlatMapFunction<Iterator<String>, double[]>() {
                @Override
                public Iterator<double[]> call(final Iterator<String> iterator) throws Exception {

                    final List<double[]> listOfMinMaxValue = new ArrayList<double[]>();

                    double[] minPoint = null;
                    double[] maxPoint = null;

                    if (iterator.hasNext()) {
                        final String[] pointValues = iterator.next().split("(;|,|\\s)");
                        minPoint = new double[pointValues.length];
                        maxPoint = new double[pointValues.length];
                        for (int i = 0; i < pointValues.length; i++) {
                            minPoint[i] = Double.parseDouble(pointValues[i]);
                            maxPoint[i] = Double.parseDouble(pointValues[i]);
                        }
                    }

                    while (iterator.hasNext()) {

                        final String[] pointValues = iterator.next().split("(;|,|\\s)");

                        for (int i = 0; i < pointValues.length; i++) {

                            final double currentValue = Double.parseDouble(pointValues[i]);

                            if (currentValue < minPoint[i]) {
                                minPoint[i] = currentValue;
                            }
                            if (currentValue > maxPoint[i]) {
                                maxPoint[i] = currentValue;
                            }
                        }

                    }

                    if (minPoint != null) {
                        listOfMinMaxValue.add(minPoint);
                    }
                    if (maxPoint != null) {
                        listOfMinMaxValue.add(maxPoint);
                    }

                    return listOfMinMaxValue.iterator();
                }
            }).persist(StorageLevel.MEMORY_AND_DISK());

            minValues = datasetPoints.reduce(Reducer.GET_MIN_DOUBLE_VALUES);
            maxValues = datasetPoints.reduce(Reducer.GET_MAX_DOUBLE_VALUES);
            datasetPoints.unpersist();

        } else {
            Arrays.fill(minValues, 0);
            Arrays.fill(maxValues, 1);
        }

        //Initialize the global bitset
        final BitSet dimensionRemoved = new BitSet();

        System.out.println("Min values:");
        System.out.println(Arrays.toString(minValues));
        System.out.println("Max values:");
        System.out.println(Arrays.toString(maxValues));

        int tempDimensionRemoved = -blockSize;

        while((dimensionality - tempDimensionRemoved) > blockSize && tempDimensionRemoved != dimensionRemoved.cardinality()){

            tempDimensionRemoved = dimensionRemoved.cardinality();

            //LOGGER.debug(blockSize + " quantity of dimensions for each step...");
            System.out.println(blockSize + " quantity of dimensions for each step...");

            for(int start = 0; start < dimensionality; ){

                //Index starts from 0, so we need to subtract 1
                int endPoint = (start + blockSize) - 1;
                int quantityOfRemovedInRange = 0;

                for(int end = 0, x = 0; end < dimensionality || end == (start * 2); end++, x++){
                    if(dimensionRemoved.get(start+x)){
                        quantityOfRemovedInRange++;
                    }
                }

                endPoint += quantityOfRemovedInRange;

                //Maximum endpoint is the dimensionality of the whole dataset
                endPoint = Math.min(endPoint, dimensionality - 1);
                if(endPoint - start + 1 == 1){
                    break;
                }

                //LOGGER.debug("Starting from " + start + " to " + endPoint + " ...");
                System.out.println("Starting from " + start + " to " + endPoint + " ...");

                //Verify the removed dimensions

                //min and max values cloned!!!
                LOGGER.debug("Making the mapping of the tree");
                final TreeMapper treeMapper = new TreeMapper(dimensionRemoved, start, endPoint, treeLevel, labeled, minValues.clone(), maxValues.clone());
                final JavaPairRDD<BitSet, Integer> mappingTree = datasetFile.flatMapToPair(treeMapper);

                LOGGER.debug("Making the counting of the tree");
                final JavaPairRDD<BitSet, Integer> countingTree = mappingTree.reduceByKey(Reducer.COUNT_REDUCER_INTEGER).persist(StorageLevel.MEMORY_AND_DISK());

                LOGGER.debug("Getting the log-log values");
                final PointsDistribution pointsDistribution = new PointsDistribution(treeLevel);
                final Map<Double, Double> logLogValues = countingTree.mapToPair(pointsDistribution).reduceByKey(Reducer.COUNT_REDUCER_DOUBLE).reduceByKeyLocally(Reducer.COUNT_REDUCER_DOUBLE);

                final ArrayList<Double> logR = new ArrayList<Double>();
                final ArrayList<Double> logSqrR = new ArrayList<Double>();
                populateLogLogArrays(logLogValues, logR, logSqrR, true);

                LOGGER.debug("Calculating the fractal dimension of whole dataset...");
                final Triple fractalDimension = Fractal.calculateFractal(logR, logSqrR, 0.015);
                //LOGGER.info("The fractal dimension of whole dataset is: " + fractalDimension);
                System.out.println("The fractal dimension of whole dataset is: " + fractalDimension);
                stringBuilder.append("The fractal dimension of whole dataset is: " + fractalDimension).append("\n");

                // Approximates the fractal dimension to top to infer the intrinsic dimension
                final int intrinsicDimension = (int) Math.ceil(fractalDimension.getAMinimum());
                final double intrinsicFractal = fractalDimension.getAMinimum();

                JavaPairRDD<BitSet, Integer> temporaryCountingTree = countingTree;
                JavaPairRDD<BitSet, Integer> bestTreeDimensionReducer = countingTree;
                JavaPairRDD<BitSet, Integer> removedDimensionReducer;

                double currentIntrinsicDimension = fractalDimension.getAMinimum();

                Triple lastFractalDimension = new Triple();
                //final BitSet dimensionRemoved = new BitSet();

                // Remove all the insignificant dimensions
                LOGGER.debug("Removing all the insignificant dimensions...");
                for (int i = 0; i < (endPoint - start - quantityOfRemovedInRange + 1) - intrinsicDimension && Math.abs(intrinsicFractal / currentIntrinsicDimension) - 1 < limitCut; i++) {

                    double temporaryIntrinsicDimension = Double.MAX_VALUE;
                    int dimensionToRemove = 0;

                    for (int j = start; j <= endPoint; j++) {

                        if (dimensionRemoved.get(j)) {
                            LOGGER.debug((j + 1) + "ª dimension already removed!");
                            continue;
                        }

                        //Sends dimension j to be removed
                        final TreeReducer treeReducer = new TreeReducer(dimensionality, treeLevel, j);
                        removedDimensionReducer = temporaryCountingTree.mapToPair(treeReducer).reduceByKey(Reducer.COUNT_REDUCER_INTEGER);

                        // Get the log-log values
                        final Map<Double, Double> logLogValuesTemporary = removedDimensionReducer.mapToPair(pointsDistribution).reduceByKey(Reducer.COUNT_REDUCER_DOUBLE).reduceByKeyLocally(Reducer.COUNT_REDUCER_DOUBLE);

                        final ArrayList<Double> temporaryLogR = new ArrayList<Double>();
                        final ArrayList<Double> temporaryLogSqrR = new ArrayList<Double>();
                        populateLogLogArrays(logLogValuesTemporary, temporaryLogR, temporaryLogSqrR, false);

                        final Triple temporaryFractalDimension = Fractal.calculateFractal(temporaryLogR, temporaryLogSqrR, 0.015);

                        if (Math.abs(currentIntrinsicDimension - temporaryFractalDimension.getAMinimum()) < temporaryIntrinsicDimension) {
                            temporaryIntrinsicDimension = Math.abs(currentIntrinsicDimension - temporaryFractalDimension.getAMinimum());
                            bestTreeDimensionReducer = removedDimensionReducer;
                            dimensionToRemove = j;
                            lastFractalDimension = temporaryFractalDimension;
                        }

                    }

                    dimensionRemoved.set(dimensionToRemove, true);
                    temporaryCountingTree.unpersist();
                    temporaryCountingTree = bestTreeDimensionReducer;
                    temporaryCountingTree.persist(StorageLevel.MEMORY_AND_DISK());
                    LOGGER.debug("Current removed dimensions: " + dimensionRemoved.toString());
                    currentIntrinsicDimension = lastFractalDimension.getAMinimum();

                    stringBuilder.append("Removed dimension: " + dimensionToRemove).append("\n");
                    stringBuilder.append(lastFractalDimension).append("\n");

                }

                LOGGER.info("Fractal dimension after dimensionality reduction: " + lastFractalDimension);

                stringBuilder.append("Non-redundant dimensions are: {");
                for (int i = 0; i < dimensionality; i++) {
                    if (!dimensionRemoved.get(i)) {
                        stringBuilder.append(i).append(", ");
                    }
                }
                stringBuilder.append("}\nFractal dimension after dimensionality reduction: " + lastFractalDimension).append("\n");

                start = endPoint + 1;
            }

        }

        //Print total time to process the dataset
        stringBuilder.append("Total time: " + ((System.currentTimeMillis() - initialTime) / 1000)).append("\n");


        saveResultsOnFile();
        System.exit(0);
    }


    public static void reduceDimensionality(int start, int end){



    }



    private static void populateLogLogArrays(final Map<Double, Double> logLogValues,
                                             final ArrayList<Double> logR,
                                             final ArrayList<Double> logSqrR,
                                             final boolean print) {
        final SortedSet<Double> keys = new TreeSet<Double>(logLogValues.keySet()).descendingSet();

        for (final Double key : keys) {
            Double CountSumSquared = Math.log(logLogValues.get(key));

            if (CountSumSquared.isNaN() || CountSumSquared.isInfinite()) {
                CountSumSquared = 0.0;
            }

            logR.add(key);
            logSqrR.add(CountSumSquared);
            if (print) {
                //TODO: Remove it!
                final String result = key + "\t" + CountSumSquared;
                stringBuilder.append(result.replace(".", ",")).append("\n");
            }
        }
    }


    private static void saveResultsOnFile() {

        try {
            bufferedWriter.write(stringBuilder.toString());
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (final IOException e) {
            e.printStackTrace();
            System.exit(-1);
        }

    }


}
