package core;

import org.apache.spark.api.java.function.PairFunction;
import scala.Tuple2;

import java.util.BitSet;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class TreeReducer implements PairFunction<Tuple2<BitSet, Integer>, BitSet, Integer> {

    private final int dimensionality;
    private final int treeLevel;
    private final int dimensionToRemove;

    /**
     * TreeReducer is used when removing the irrelevant dimensions,it remove each dimension from each tuple
     * of the origin counting tree.
     *
     * @param dimensionality    Embedded dimensionality of the dataset.
     * @param treeLevel         Quantity of tree levels to be created.
     * @param dimensionToRemove The specific dimension to be removed from counting tree.
     */
    public TreeReducer(final int dimensionality, final int treeLevel, final int dimensionToRemove) {
        this.dimensionality = dimensionality;
        this.treeLevel = treeLevel;
        this.dimensionToRemove = dimensionToRemove;
    }

    @Override
    public Tuple2<BitSet, Integer> call(final Tuple2<BitSet, Integer> tuple) throws Exception {
        final BitSet treeId = (BitSet) tuple._1.clone();

        // Quantity of bits reserved to identify the tree level
        final int quantityOfBitsLevel = (int) Math.ceil(Math.log10(this.treeLevel) / Math.log10(2));

        for (int currentLevel = 0; currentLevel < this.treeLevel; currentLevel++) {
            // Improve it to improve the memory use
            // * Each dimension removed one place of the bit is reduced ==> 001 -> 010
            // Remove the dimensions
            treeId.set(dimensionToRemove + (currentLevel * this.dimensionality) + quantityOfBitsLevel, false);
        }

        return new Tuple2<BitSet, Integer>(treeId, tuple._2);
    }
}
