package core;

import java.io.Serializable;
import java.util.BitSet;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class Cell implements Serializable {
    private static final long serialVersionUID = 1L;

    private int totalOfPoints;
    protected Node nextLevel;

    public Cell(){
        this.totalOfPoints = 0;
        this.nextLevel = null;
    }

    public void incrementTotalOfPoints(){
        this.totalOfPoints++;
    }

    public void addChild(final BitSet nodeKey){
        if(this.nextLevel == null){
            this.nextLevel = new Node();
        }

        this.nextLevel.insertPoint(nodeKey);
    }

    //Getters and Setters

    public int getTotalOfPoints() {
        return this.totalOfPoints;
    }

}
