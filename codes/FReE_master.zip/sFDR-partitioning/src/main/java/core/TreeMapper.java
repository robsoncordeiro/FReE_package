package core;

import org.apache.spark.api.java.function.PairFlatMapFunction;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Iterator;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class TreeMapper implements PairFlatMapFunction<String, BitSet, Integer> {

    private final BitSet dimensionRemoved;
    private final int startDimension;
    private final int endDimension;
    //private final int dimensionality;
    private final int treeLevel;
    private final int labeled;
    private final double[] minValues;
    private final double[] maxValues;

    /**
     * Mapper will map all the points from a dataset.
     * <p>
     * The tree is mapped as a key-value mode, where the key is a set of bits containing information about the current
     * level of the tree and the position of the point and the value is the quantity of points in that specific area.
     * <p>
     * <p>
     * <br/><b>Example of the key:</b>
     * {level | position}
     * {01011 | 10010110}
     * <p>
     * <br/><b>Example of the tuple node:</b>
     * {0101110010110, 5}
     *
     * @param startDimension The initial index to start the tree mapping
     * @param endDimension   The final index to do the tree mapping
     * @param treeLevel      Quantity of tree levels to be created.
     * @param labeled        If the dataset is labeled, generally the real point starts from index 1,
     *                       otherwise it can be 0.
     */

    public TreeMapper(final BitSet dimensionRemoved,
                      final int startDimension,
                      final int endDimension,
                      final int treeLevel,
                      final int labeled,
                      final double[] minValues,
                      final double[] maxValues) {

        this.dimensionRemoved = dimensionRemoved;
        this.startDimension = startDimension;
        this.endDimension = endDimension;
        //this.dimensionality = dimensionality;
        this.treeLevel = treeLevel;
        this.labeled = labeled;
        this.minValues = minValues;
        this.maxValues = maxValues;
    }

    @Override
    public Iterator<Tuple2<BitSet, Integer>> call(final String s) throws Exception {
        final ArrayList<Tuple2<BitSet, Integer>> tree = new ArrayList<Tuple2<BitSet, Integer>>();

        int quantityOfRemainingDimensions = 0;

        double middle;

        final double[] point = new double[this.endDimension - this.startDimension + 1];
        final double[] min = new double[this.endDimension - this.startDimension + 1];
        final double[] max = new double[this.endDimension - this.startDimension + 1];
        BitSet treeId = new BitSet();

        // Regex to split comma/space-separated values
        final String[] pointValues = s.split("(;|,|\\s)");

        for (int i = 0, j = this.startDimension; j <= this.endDimension; j++) {
            if(this.dimensionRemoved.get(j)){
                continue;
            }
            point[i] = ((Double.parseDouble(pointValues[j + this.labeled]) - minValues[j+this.labeled]) / (maxValues[j + this.labeled] - minValues[j+this.labeled]));
//            max[i] = maxValues[j + this.labeled];
            max[i] = 1;
//            min[i] = minValues[j + this.labeled];
            min[i] = 0;
            quantityOfRemainingDimensions++;
            i++;
        }

        // Quantity of bits reserved to identify the tree level
        final int quantityOfBitsLevel = (int) Math.ceil(Math.log10(this.treeLevel) / Math.log10(2));

        for (int currentLevel = 0; currentLevel < this.treeLevel; currentLevel++) {
            treeId = (BitSet) treeId.clone();

            // Set the corresponding level bits of the tree
            for (int i = currentLevel, j = 0; i > 0; i >>>= 1, j++) {
                treeId.set(j, (i & 1) == 1);
            }

            for (int i = 0; i < quantityOfRemainingDimensions; i++) {
                middle = ((max[i] - min[i]) / 2.0) + min[i];

                if (point[i] > middle) {
                    treeId.set(i + (currentLevel * quantityOfRemainingDimensions) + quantityOfBitsLevel, true);
                    min[i] = middle;
                } else {
                    max[i] = middle;
                }
            }

            //Insert the tuple on treeMapper
            tree.add(new Tuple2<BitSet, Integer>(treeId, 1));
        }

        return tree.iterator();
    }

}
