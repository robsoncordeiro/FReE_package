package core;

import java.io.Serializable;
import java.util.BitSet;
import java.util.TreeMap;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 *
 */

public class Node implements Serializable {
    private static final long serialVersionUID = 1L;
    private final TreeMap<BitSet, Cell> cells; //Try use of other structures, such as HashMap


    public Node(){
        this.cells = new TreeMap<BitSet, Cell>();
    }

    public Cell insertPoint(final BitSet nodeKey){
        Cell targetCell = this.cells.get(nodeKey);

        if(targetCell == null){
            targetCell = new Cell();
            targetCell.nextLevel = new Node();
        }

        targetCell.incrementTotalOfPoints();
        cells.put(nodeKey, targetCell);

        return targetCell;
    }

}
