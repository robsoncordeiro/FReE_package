package utils;

import java.io.Serializable;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class Triple implements Serializable {
    private static final long serialVersionUID = 1L;

    private double aMinimum;
    private double bMinimum;
    private double error;

    public Triple(final double aMinimum, final double bMinimum, final double error) {
        this.aMinimum = aMinimum;
        this.bMinimum = bMinimum;
        this.error = error;
    }

    public Triple() {
        this(0.0, 0.0, 0.0);
    }


    //Getters

    public double getAMinimum() {
        return this.aMinimum;
    }

    public double getBMinimum() {
        return this.bMinimum;
    }

    public double getError() {
        return this.error;
    }


    //Setters

    public void setAMinimum(final double aMinimum) {
        this.aMinimum = aMinimum;
    }

    public void setBMinimum(final double bMinimum) {
        this.bMinimum = bMinimum;
    }

    public void setError(final double error) {
        this.error = error;
    }


    // Override

    @Override
    public String toString() {
        return "a = " + this.getAMinimum() + " b = " + this.getBMinimum() + " error = " + this.getError();
    }
}
