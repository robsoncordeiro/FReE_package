package utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class PointSet implements Serializable {
    private static final long serialVersionUID = 1L;

    private ArrayList<Double> logR;
    private ArrayList<Double> logSqrR;
    private Triple triple;
    private double slope;

    private int firstPoint;
    private int lastPoint;
    private int count;
    private int maxCount;

    public PointSet() {
        this.logR = new ArrayList<Double>();
        this.logSqrR = new ArrayList<Double>();
    }

    public PointSet(final int maxCount) {
        this();
        this.maxCount = maxCount;

        for (int i = 0; i < this.maxCount; i++) {
            logR.add(0.0);
            logSqrR.add(0.0);
        }
    }

    public PointSet(final PointSet pointSet) {
        this.setFirstPoint(pointSet.getFirstPoint());
        this.setLastPoint(pointSet.getLastPoint());
        this.setCount(pointSet.getCount());
        this.setMaxCount(pointSet.getMaxCount());
        this.setLogR(pointSet.getLogR());
        this.setLogSqrR(pointSet.getLogSqrR());
        this.setTriple(pointSet.getTriple());
    }

    public void calculateSlope() {
        final Triple triple = Fractal.linearRegression(this.getLogR(), this.getLogSqrR());
        this.setSlope(triple.getAMinimum());
    }

    // Getters

    public ArrayList<Double> getLogR() {
        return logR;
    }

    public ArrayList<Double> getLogSqrR() {
        return logSqrR;
    }

    public Triple getTriple() {
        return triple;
    }

    public int getFirstPoint() {
        return firstPoint;
    }

    public int getLastPoint() {
        return lastPoint;
    }

    public int getCount() {
        return count;
    }

    public int getMaxCount() {
        return maxCount;
    }

    public double getSlope() {
        return this.slope;
    }

    // Setters


    public void setLogR(final List<Double> logR) {
        this.logR = new ArrayList<Double>();
        this.logR.addAll(logR);
    }

    public void setLogSqrR(final List<Double> logSqrR) {
        this.logSqrR = new ArrayList<Double>();
        this.logSqrR.addAll(logSqrR);
    }

    public void setTriple(final Triple triple) {
        this.triple = triple;
    }

    public void setSlope(final double slope) {
        this.slope = slope;
    }

    public void setFirstPoint(final int firstPoint) {
        this.firstPoint = firstPoint;
    }

    public void setLastPoint(final int lastPoint) {
        this.lastPoint = lastPoint;
    }

    public void setCount(final int count) {
        this.count = count;
    }

    public void setMaxCount(final int maxCount) {
        this.maxCount = maxCount;
    }
}
