package utils;

import org.apache.spark.api.java.function.Function2;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class Reducer implements Serializable {
    private static final long serialVersionUID = 1L;


    public static final Function2<Integer, Integer, Integer> COUNT_REDUCER_INTEGER = new Function2<Integer, Integer, Integer>() {
        public Integer call(final Integer integer1, final Integer integer2) throws Exception {
            return integer1 + integer2;
        }
    };

    public static final Function2<Double, Double, Double> COUNT_REDUCER_DOUBLE = new Function2<Double, Double, Double>() {
        public Double call(final Double aDouble1, final Double aDouble2) throws Exception {
            return aDouble1 + aDouble2;
        }
    };

    public static final Function2<BigDecimal, BigDecimal, BigDecimal> COUNT_REDUCER_BIGDECIMAL = new Function2<BigDecimal, BigDecimal, BigDecimal>() {
        @Override
        public BigDecimal call(final BigDecimal bigDecimal1, final BigDecimal bigDecimal2) throws Exception {
            return bigDecimal1.add(bigDecimal2);
        }
    };


    public static final Function2<double[], double[], double[]> GET_MIN_DOUBLE_VALUES = new Function2<double[], double[], double[]>() {
        @Override
        public double[] call(final double[] doubles, final double[] doubles2) throws Exception {
            for (int i = 0; i < doubles.length; i++) {
                doubles[i] = Math.min(doubles[i], doubles2[i]);
            }
            return doubles;
        }
    };

    public static final Function2<double[], double[], double[]> GET_MAX_DOUBLE_VALUES = new Function2<double[], double[], double[]>() {
        @Override
        public double[] call(final double[] doubles, final double[] doubles2) throws Exception {
            for (int i = 0; i < doubles.length; i++) {
                doubles[i] = Math.max(doubles[i], doubles2[i]);
            }
            return doubles;
        }
    };

    public static final Function2<double[][], double[][], double[][]> REDUCER_MIN_MAX_DOUBLE = new Function2<double[][], double[][], double[][]>() {
        @Override
        public double[][] call(final double[][] doubles1, final double[][] doubles2) throws Exception {
            final double[][] minMaxValues = new double[2][doubles1[0].length];

            for (int i = 0; i < doubles1[0].length; i++) {
                minMaxValues[0][i] = Math.min(doubles1[0][i], doubles2[0][i]);
                minMaxValues[1][i] = Math.max(doubles1[0][i], doubles2[0][i]);
            }

            return minMaxValues;
        }
    };

}
