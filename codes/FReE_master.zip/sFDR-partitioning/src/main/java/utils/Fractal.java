package utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class Fractal implements Serializable {
    private static final long serialVersionUID = 1L;


    @Deprecated
    public static Triple calculateFractal2(final ArrayList<Double> logR, final ArrayList<Double> logSqrR) {
        Triple errorMinusBottom;
        Triple errorMinusTop;
        Triple auxiliaryError;
        final int minLen = (int) Math.ceil(logR.size() / 2.0);

        int bottom = 0;
        int top = logR.size();

        Triple error = linearRegression(logR, logSqrR);
        auxiliaryError = error;


        while (((top - bottom) >= minLen) && !(logSqrR.get(top - 1).equals(logSqrR.get(bottom)))) {

            errorMinusBottom = linearRegression(logR.subList(bottom + 1, top), logSqrR.subList(bottom + 1, top));
            errorMinusTop = linearRegression(logR.subList(bottom, top - 1), logSqrR.subList(bottom, top - 1));

            if (errorMinusBottom.getError() < errorMinusTop.getError()) {
                bottom++;
                error = errorMinusBottom;
            } else {
                top--;
                error = errorMinusTop;
            }

            if (error.getError() < auxiliaryError.getError()) {
                auxiliaryError = error;
            }

        }

        return error;
    }


    /**
     * calculateFractal is a method to return the Fractal dimension based on RLA algorithm, proposed by Elaine Parros
     * (http://www.teses.usp.br/teses/disponiveis/55/55134/tde-01092006-113751/pt-br.php)
     *
     * @param logR     log values of radii [r1, r2] used
     * @param logSqrR  log values of squared counts
     * @param maxFitError maximum error allowed for the line-fitting
     * @return fractal dimension D2
     */
    public static Triple calculateFractal(final ArrayList<Double> logR, final ArrayList<Double> logSqrR, final double maxFitError) {

        final int totalOfPoints = logR.size();
        final double minimumSlope = 0.10;
        final double maximumSlopeError = 0.30;
        final double minimumFitError = maxFitError / 10.0;

        Triple triple = linearRegression(logR, logSqrR);


        if (triple.getError() == Double.MAX_VALUE) {
            triple.setError(0.0);
        }


        if (triple.getError() > minimumFitError) {

            final ArrayList<PointSet> minimumRegions = new ArrayList<PointSet>();

            for (int i = 0; i < totalOfPoints - 1; i++) {
                final PointSet pointSet = new PointSet(2);
                pointSet.setLogR(logR.subList(i, i + 2));
                pointSet.setLogSqrR(logSqrR.subList(i, i + 2));
                pointSet.calculateSlope();

                if (pointSet.getSlope() >= minimumSlope && pointSet.getSlope() != Double.MAX_VALUE) {
                    minimumRegions.add(pointSet);
                }
            }


            double differenceSum = 0;
            double quantityOfComparisons = 0;
            double minimumSlopeDifference = Double.MAX_VALUE;
            double maximumSlopeDifference = Double.MIN_VALUE;

            for (int i = 0; i < minimumRegions.size() - 1; i++) {
                final double difference = Math.abs(minimumRegions.get(i).getSlope() - minimumRegions.get(i + 1).getSlope()) /
                        (minimumRegions.get(i).getSlope() + minimumRegions.get(i + 1).getSlope());

                if (minimumRegions.get(i).getSlope() >= minimumSlope || minimumRegions.get(i + 1).getSlope() >= minimumSlope) {
                    differenceSum += difference;
                    minimumSlopeDifference = Math.min(minimumSlopeDifference, difference);
                    maximumSlopeDifference = Math.max(maximumSlopeDifference, difference);
                    quantityOfComparisons++;
                }
            }

            double meanDifference;
            // If there is at least three minimumRegions to be considered
            if (minimumRegions.size() >= 4 && quantityOfComparisons > 2) {
                differenceSum -= minimumSlopeDifference;
                differenceSum -= maximumSlopeDifference;
                meanDifference = differenceSum / (quantityOfComparisons - 2);
            } else {
                meanDifference = differenceSum / (minimumRegions.size() - 1);
            }

            if (meanDifference > maximumSlopeError) {
                meanDifference = maximumSlopeError;
            }


            double stepDifference = meanDifference / 2.0;
            final double slope = stepDifference / 2.0;

            while (stepDifference <= meanDifference) {

                for (int i = 0; i < minimumRegions.size() - 1; i++) {

                    double difference = 0.0;

                    if (minimumRegions.get(i).getSlope() >= minimumSlope || minimumRegions.get(i + 1).getSlope() >= minimumSlope) {
                        difference = Math.abs(minimumRegions.get(i).getSlope() - minimumRegions.get(i + 1).getSlope()) /
                                (minimumRegions.get(i).getSlope() + minimumRegions.get(i + 1).getSlope());
                    }

                    if (difference < stepDifference) {
                        final List<Double> temporaryLogR = new ArrayList<Double>(minimumRegions.get(i).getLogR());
                        temporaryLogR.addAll(minimumRegions.get(i + 1).getLogR());

                        final List<Double> temporaryLogSqrR = new ArrayList<Double>(minimumRegions.get(i).getLogSqrR());
                        temporaryLogSqrR.addAll(minimumRegions.get(i + 1).getLogSqrR());

                        triple = linearRegression(temporaryLogR, temporaryLogSqrR);

                        if (triple.getError() == Double.MAX_VALUE) {
                            triple.setError(0.0);
                        }

                        if (triple.getError() < maxFitError) {
                            final PointSet pointSet = new PointSet();
                            pointSet.setLogR(temporaryLogR);
                            pointSet.setLogSqrR(temporaryLogSqrR);
                            pointSet.setSlope(triple.getError());


                            // Add the new region and remove the two origin regions
                            minimumRegions.add(i, pointSet);
                            minimumRegions.remove(i + 1);
                            minimumRegions.remove(i + 1);
                        }

                    }

                }

                int auxCount = 0;
                while (auxCount < minimumRegions.size() && (minimumRegions.get(auxCount).getSlope() < stepDifference ||
                        minimumRegions.get(auxCount).getSlope() >= meanDifference)) {
                    auxCount++;
                }


                if (auxCount == minimumRegions.size()) {
                    break;
                }


                stepDifference = stepDifference + slope;

            }

            int max = 0;

            for (int i = 0; i < minimumRegions.size(); i++) {

                if (minimumRegions.get(i).getLogR().size() > max) {
                    triple = linearRegression(minimumRegions.get(i).getLogR(), minimumRegions.get(i).getLogSqrR());
                    max = minimumRegions.get(i).getLogR().size();
                }

            }
        }

        return triple;
    }


    static Triple linearRegression(final List<Double> logR, final List<Double> logSqrR) {
        final int quantityOfPoints = logR.size();
        double sumX = 0;
        double sumY = 0;
        double sumXY = 0;
        double sumXX = 0;
        double sumYY = 0;

        final Triple triple = new Triple();

        for (int i = 0; i < quantityOfPoints; i++) {
            sumX += logR.get(i);
            sumY += logSqrR.get(i);
            sumXY += (logR.get(i) * logSqrR.get(i));
            sumXX += (logR.get(i) * logR.get(i));
            sumYY += (logSqrR.get(i) * logSqrR.get(i));
        }

        if (((quantityOfPoints * sumXX) - (sumX * sumX)) <= 0 || ((quantityOfPoints * sumYY) - (sumY * sumY)) <= 0) {
            triple.setError(Double.MAX_VALUE);
            return triple;
        }


        final double aMinimum = ((quantityOfPoints * sumXY) - (sumX * sumY)) / ((quantityOfPoints * sumXX) - (sumX * sumX));
        final double bMinimum = (sumY - (aMinimum * sumX)) / quantityOfPoints;
        final double error = ((quantityOfPoints * sumXY) - (sumX * sumY)) / (Math.sqrt((quantityOfPoints * sumXX) - (sumX * sumX)) * Math.sqrt((quantityOfPoints * sumYY) - (sumY * sumY)));


        triple.setAMinimum(aMinimum);
        triple.setBMinimum(bMinimum);
        triple.setError(1 - Math.abs(error));

        return triple;
    }


}
