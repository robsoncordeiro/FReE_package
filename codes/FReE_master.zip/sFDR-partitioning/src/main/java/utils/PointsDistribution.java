package utils;

import org.apache.spark.api.java.function.PairFunction;
import scala.Tuple2;

import java.util.BitSet;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class PointsDistribution implements PairFunction<Tuple2<BitSet, Integer>, Double, Double> {

    private final int treeLevel;

    public PointsDistribution(final int treeLevel) {
        this.treeLevel = treeLevel;
    }

    @Override
    public Tuple2<Double, Double> call(final Tuple2<BitSet, Integer> tuple) throws Exception {

        // Quantity of bits reserved to identify the tree level
        final int quantityOfBitsLevel = (int) Math.ceil(Math.log10(this.treeLevel) / Math.log10(2));

        double level = 0;

        for (int i = 0; i < quantityOfBitsLevel; i++) {
            if (tuple._1.get(i)) {
                level += Math.pow(2, i);
            }
        }

        // Original
        //Double CountSumSquared = ((double) tuple._2 * (double) tuple._2);

        // Approximation - Correlation integral
        // Get in page 20 of (http://www.teses.usp.br/teses/disponiveis/55/55134/tde-01092006-113751/pt-br.php)
        Double CountSumSquared = (double) tuple._2 * ((tuple._2 - 1.0) / 2.0);

        if (CountSumSquared.isInfinite() || CountSumSquared.isNaN()) {
            CountSumSquared = 0.0;
        }

        return new Tuple2<Double, Double>(Math.log(1.0 / Math.pow(2.0, level + 1)), CountSumSquared);
    }

}
