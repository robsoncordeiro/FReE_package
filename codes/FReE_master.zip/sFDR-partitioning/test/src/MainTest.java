package src;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * @author Jadson Oliveira <jadsonjjmo@gmail.com>
 */

public class MainTest {

    @Test
    public void sierpinskiTest(){
        assertEquals(0, 0);
    }

    @Test
    public void sierpinskiTest2(){
        assertEquals(0, 1);
    }


}
