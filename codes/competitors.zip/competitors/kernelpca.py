# KPCA implementation to reduce the data dimensionality

import pandas as pd
from sklearn.decomposition import KernelPCA
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.cluster import MiniBatchKMeans
from sklearn.feature_selection import VarianceThreshold
from sklearn.preprocessing import StandardScaler
import math


def kPCA(input_dataset, columns):
	df = pd.read_csv(input_dataset, header=None, index_col=False, sep=',')
	
	#to remove the label column (optional)
	df.drop([0], axis=1, inplace=True)

	df = df[df.columns[0:columns]]

	print df.shape

	print "Scaling data...\n"
	#Scaling data to unit std
	scaler = StandardScaler(with_std=True, with_mean=False)
	df = scaler.fit_transform(df)

	print "Clustering data...\n"
	# Clustering data using a K-Means approach (based on mini batch to speedup)
	kmeans = MiniBatchKMeans(n_clusters=(columns)*int(math.log10(columns)//math.log10(2)+1), random_state=0).fit(df)
	kmeans_center = kmeans.cluster_centers_

	print "Transforming data...\n"
	# Kernel PCA: get the kernel-matrix and fit the data
	kernel_PCA = KernelPCA(n_components=columns, kernel='poly', degree=2, copy_X=False)
	kernel_PCA = kernel_PCA.fit(kmeans_center)
	df_new = kernel_PCA.transform(df)
	df = None

	print "Getting the explained variance of data transformed...\n"
	get_variance = VarianceThreshold()
	get_variance.fit_transform(df_new)

	data_variances = get_variance.variances_
	sum_variances = sum(data_variances)

	variances_array = []
	for item in data_variances:
		variances_array.append(item/sum_variances)

	variances_array = sorted(variances_array, reverse=True)

	print variances_array



# Enter with an array of tuples, to process the datasets (each tuple needs the path and the dimensionality
datasets = [('datasets/SUSY.csv', 18)]

for item in datasets:
	# Increase the range to run the algorithm several times
	for step in range(1):
		print (item, step)
		kPCA(input_dataset=item[0], columns=item[1])
		print '\n'

exit()
